package com.atha.treemapindia;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;

public class Layer_Selection extends Activity{

	private List<EditText> allEds = new ArrayList<EditText>();
	private List<Spinner> allSpinners = new ArrayList<Spinner>();
	private DBHelper dbHelper=null;
	private static ArrayList<Attribute> layerList= new ArrayList<Attribute>();
	public static ArrayList<Attribute> getLayerList() {
		return layerList;
	}
	public static void setLayerList(ArrayList<Attribute> layerList) {
		Layer_Selection.layerList = layerList;
	}
	
	protected void onCreate(Bundle savedInstanceState)
	{
//		System.out.println("hi");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layer_selection);
		

		  
		Button btnAddAttr = (Button)findViewById(R.id.addLayer);
		btnAddAttr.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	createTableRow(v);

            } // end onClick
        }); // end setOnClickListener
		
		
//		final EditText editText = (EditText) findViewById(R.id.editText1);
    	
		dbHelper= new DBHelper(this);
		Button buttonNext = (Button)findViewById(R.id.next);
		buttonNext.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	//
            	layerList.removeAll(getLayerList());
            	for(int i=0; i < allEds.size(); i++){
            	    //hashmap.put(allEds.get(i).getText().toString(),"INTEGER");
            		Attribute attribute = new Attribute();
            		attribute.setName(allEds.get(i).getText().toString());
            		attribute.setType("Text");
            		layerList.add(attribute); 		
            		
            	}
            	SQLiteDatabase db;
            	db=dbHelper.openDatabase();
            	
            	//if(dbHelper.getBase_table_created()==0)
            	//{
            	dbHelper.createBaseTables(db);
            	//}
            	DBHelper.insertintoLayerTable(getLayerList());
            	db.close();
            	Intent mainIntent = new Intent(Layer_Selection.this, Attribute_Selection.class);
				//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				//mainIntent.putExtra("attributeList", layerList);
				//mainIntent.putExtra("objectName", object_Name);
				startActivity(mainIntent);
				Layer_Selection.this.finish();

            } // end onClick
        }); // end setOnClickListene
	}
	
	
	
	public void createTableRow(View v) {
		  //final Attribute attribute = new Attribute();
		  TableLayout tl = (TableLayout) findViewById(R.id.attrTableLayout);
		  TableRow tr = new TableRow(this);
		  LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		  tr.setLayoutParams(lp);

		  EditText attName = new EditText(this);
		  attName.setLayoutParams(lp);
		  allEds.add(attName);

/*		  Spinner attType =new Spinner(this);
		  attType.setLayoutParams(lp);
		  allSpinners.add(attType);
		  ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
			        R.array.selection_name , android.R.layout.simple_spinner_item);
		  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  attType.setAdapter(adapter);
		  */
		  /*attType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				
				@Override
				public void onItemSelected(AdapterView<?> parent, View view,  int pos, long id)
				{
	
					String item=parent.getItemAtPosition(pos).toString();
					//selectedAttr = item;
			//		attribute.setType(item);
					
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {
					// TODO Auto-generated method stub
					
				}

				
			});*/
		  
		  tr.addView(attName);
		  //tr.addView(attType);
		  tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
	
	
	
}



