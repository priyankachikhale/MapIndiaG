package com.atha.treemapindia;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import com.google.android.apps.mytracks.content.MyTracksProviderUtils;
import com.google.android.apps.mytracks.content.Track;
import com.google.android.apps.mytracks.content.Waypoint;
import com.google.android.apps.mytracks.services.ITrackRecordingService;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TableRow.LayoutParams;
import android.widget.Toast;

public class Screen_Selection extends Activity{
	
	private ArrayList<Screens> screenList;
	String user;
	SQLiteDatabase db;
	DBHelper dbHelper;
	String domain;
	Screens scr;
	String androidId;
	Track track;
	private Uri	                   outputFileUri;
	private static int	           TAKE_PICTURE	       = 1;
	private MyTracksProviderUtils	myTracksProviderUtils;
	private ITrackRecordingService	myTracksService;

	// intent to access the MyTracks service
	private Intent	               intent, intent_cam;

	// connection to the MyTracks service
	/*private ServiceConnection	   serviceConnection	= new ServiceConnection() {
		                                                   @Override
		                                                   public void onServiceConnected(ComponentName className, IBinder service)
		                                                   {
			                                                   myTracksService = ITrackRecordingService.Stub.asInterface(service);
		                                                   }

		                                                   @Override
		                                                   public void onServiceDisconnected(ComponentName className)
		                                                   {
			                                                   myTracksService = null;
		                                                   }

														
	                                                   };
*/	                                                   
	protected void onCreate(Bundle savedInstanceState)
	{
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.screen_selection);
		
		androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
		myTracksProviderUtils = MyTracksProviderUtils.Factory.get(this);

		// Intent for start service
		intent = new Intent();
		ComponentName componentName = new ComponentName(getString(R.string.mytracks_service_package), getString(R.string.mytracks_service_class));
		intent.setComponent(componentName);
		
		user=LoginActivity.getLogin();
		
		dbHelper= new DBHelper(this);
		db=dbHelper.openDatabase();
		
		domain=dbHelper.getUserDomain(user, db);
    	screenList=dbHelper.getScreensForUser(user,db);
    	
    

    	Button buttonback = (Button)findViewById(R.id.back);
		buttonback.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
		Intent mainIntent = new Intent(Screen_Selection.this, Layer_Selection_Show.class);
		//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
		/*mainIntent.putExtra("attributeList", attributeList);
		mainIntent.putExtra("objectName", object_Name);*/
		startActivity(mainIntent);
		Screen_Selection.this.finish();
            } // end onClick
        }); // end setOnClickListen
    	

    	TableLayout tl = (TableLayout) findViewById(R.id.screenTableLayout);
		LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		
    	Iterator<Screens> it=screenList.iterator();
    	int i=2;
		while(it.hasNext()){
			
			//scr=new Screens();
			scr=it.next();
			Button button = new Button(this);
		    button.setId(i+1);
		    button.setText(scr.getName());
		   
		    button.setOnClickListener(btnclick);
		    i++;

		    
			TableRow tr = new TableRow(this);
			tr.setLayoutParams(lp);
			tr.addView(button);
			tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
		
		Button tap=(Button) findViewById(R.id.take_picture);
		tap.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{

				intent_cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				track = myTracksProviderUtils.getLastTrack();
				if (track == null)
				{
					track = new Track();
					track.setId(1);
				}
				/*if (et_tno.getText().toString().length() > 0 && tree_name != null)
				{*/
					String str;
					Toast.makeText(getApplicationContext(), "press only save button when you reached near to tree", Toast.LENGTH_LONG).show();
					Waypoint waypoint = new Waypoint();
					waypoint.setTrackId(track.getId());
					waypoint.setName(user);// .toLocaleString());
					//waypoint.setDescription(tree_name);// .toLocaleString());
					waypoint.setCategory(domain);
					waypoint.setLocation(myTracksProviderUtils.getLastValidTrackPoint());
					str = (System.currentTimeMillis() + "");
					str = str.substring(str.length() - 4, str.length());
					File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + androidId + "/EMAGPS/", LoginActivity.getLogin() + "_" + str + ".jpg");
					// Toast.makeText(getApplicationContext(),imagename+"1",
					// Toast.LENGTH_SHORT).show();
					outputFileUri = Uri.fromFile(file);
					intent_cam.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
					startActivityForResult(intent_cam, TAKE_PICTURE);
					// Toast.makeText(getApplicationContext(), ""+tr.getId(),
					// Toast.LENGTH_SHORT).show();

					myTracksProviderUtils.insertWaypoint(waypoint);
				/*}
				else
				{
					Toast.makeText(getApplicationContext(), "Please Enter tree No. Or tree name", Toast.LENGTH_LONG).show();
				}*/
			}
		});
		db.close();
		
	}
	
	OnClickListener btnclick = new OnClickListener() {

        @Override
        public void onClick(View v) {
        	 Button button = (Button)v;
        	 String screen = (String) button.getText();
        	 
        	Intent mainIntent = new Intent(Screen_Selection.this, Screen_content.class);
			mainIntent.putExtra("screenName", screen);
			
			startActivity(mainIntent);
			Screen_Selection.this.finish();
            

        }

		
    };
    
    
}
