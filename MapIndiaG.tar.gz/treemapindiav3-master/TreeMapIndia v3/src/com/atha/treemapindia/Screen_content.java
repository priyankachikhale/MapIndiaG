package com.atha.treemapindia;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TableRow.LayoutParams;

public class Screen_content extends Activity{
	String screenName;
	Screens currentScreen;
	ArrayList<Attribute> screenAtt;
	String user;
	SQLiteDatabase db;
	Screens screen;
	DBHelper dbHelper;
	ArrayList<Screens> screenList;
	ArrayList<Attribute> attrRow;
	List<EditText> valueText=new ArrayList<EditText>();
	List<RadioGroup> valueRadioGroup=new ArrayList<RadioGroup>();
	LinkedHashMap<String, String> keyValue = new LinkedHashMap<String, String>();
	@SuppressWarnings("deprecation")
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.screen_content);
		screenName=getIntent().getStringExtra("screenName");
		dbHelper= new DBHelper(this);
		db=dbHelper.openDatabase();
		screenList=dbHelper.getScreensForUser(LoginActivity.getLogin(), db);
		System.out.println(screenList);
		
		
		Iterator<Screens> it=screenList.iterator();
		while(it.hasNext())
		{
			screen=it.next();
			if(screen.getName().equals(screenName))
			{
				currentScreen=screen;
				screenAtt=currentScreen.getAttributes();
				System.out.println(screenAtt);
			}
		}
		
    	
    	TableLayout tl = (TableLayout) findViewById(R.id.screen_contentTableLayout);
		LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		
		TextView title =new TextView(this);
		title.setText(screenName);
		TableRow titleRow = new TableRow(this);
		titleRow.setLayoutParams(lp);
		titleRow.addView(title);
		tl.addView(titleRow, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		int listSize;
		String[] textRange;
		String[] listRange;
		RadioGroup rg;
		RadioButton rb;
    	/*Iterator<Attribute> screenIt=screenAtt.iterator();
    	Attribute at= new Attribute();
		while(screenIt.hasNext()){*/
			for(Attribute at : screenAtt)
			{
			//at=screenIt
			
			TableRow tr = new TableRow(this);
			tr.setLayoutParams(lp);
			
			TextView name =new TextView(this); 
			name.setText(at.getName());
			tr.addView(name);
			
			
			if(at.getShowcase().equalsIgnoreCase("text")){
				EditText editText =new EditText(this);
				tr.addView(editText);
				
				if(at.getType().equalsIgnoreCase("integer"))
				{
					textRange=at.getRange().split("-");
					TextView  range =new TextView(this);
					range.setText("Add values between "+textRange[0]+" and "+textRange[1] );
					tr.addView(range);
					
				}
				valueText.add(editText);
			}
			else
			{
				listSize=0;
				listRange=at.getRange().split("/");
				rg=new RadioGroup(this);
				while(listSize!=Integer.parseInt(at.getValue()))
				{
					rb=new RadioButton(this);
					rb.setText(listRange[listSize]);
					rg.addView(rb);
					listSize++;
				}
				valueRadioGroup.add(rg);
				tr.addView(rg);
			}
			
			

		tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
		
		Button btnAddAttr = (Button)findViewById(R.id.Back);
		btnAddAttr.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	int i;
            	int indexText=0;; 
            	int indexList=0;;
            	Attribute attr;
            	RadioButton radioButton;
            	int selectedId;
            	for(i=0;i<currentScreen.getAttributes().size();i++)
            	{
            		attr=currentScreen.getAttributes().get(i);
            		
            		if(attr.getShowcase().equalsIgnoreCase("TEXT"))
            		{
            			String a=attr.getName();
            			String b=valueText.get(indexText).getText().toString();
            	
            			keyValue.put(a,b);
            			indexText++;
            		}
            		else
            		{
            			selectedId = valueRadioGroup.get(indexList).getCheckedRadioButtonId();

                        // find the radiobutton by returned id
                            radioButton = (RadioButton) findViewById(selectedId);

                        
            			keyValue.put(attr.getName().toString(), (String) radioButton.getText());
            			indexList++;
            		}
            		
            	}
            	
//            	for(i=0;i<keyValue.size();i++)
            	Iterator<Entry<String, String>> it=keyValue.entrySet().iterator();
            	while (it.hasNext())
            	{
            		Entry<String, String> en=it.next();
            		String key=en.getKey();
            		String value=en.getValue();
            		String user=LoginActivity.getLogin();
            		String domain=dbHelper.getUserDomain(user, db);
            		dbHelper.insertintoDataTable(user, currentScreen.getName(), domain, key, value, db);
                	db.close();
            	}
            	Intent mainIntent = new Intent(Screen_content.this, Screen_Selection.class);
				//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				startActivity(mainIntent);
				Screen_content.this.finish();

            } // end onClick
        }); 
	
		System.out.println("hi");
	}
	
}
