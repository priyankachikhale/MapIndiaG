package com.atha.treemapindia;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

import com.atha.treemapindia.R;
import com.google.android.apps.mytracks.content.MyTracksProviderUtils;
import com.google.android.apps.mytracks.content.Track;
import com.google.android.apps.mytracks.content.Waypoint;
import com.google.android.apps.mytracks.services.ITrackRecordingService;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TableRow.LayoutParams;

public class Main_Activity extends Activity{
	
	
	private LinkedHashMap<String, String> rowValuesHashmap = new LinkedHashMap<String, String>();
	private ArrayList<Attribute> attributeList = new ArrayList<Attribute>();
	/*private ArrayList<Attribute> valueList = new ArrayList<Attribute>();*/
	private Intent intent_cam;
	private String androidId;
	private DBHelper dbHelper;
	private SQLiteDatabase db;
	private Uri outputFileUri;
	private MyTracksProviderUtils	myTracksProviderUtils;
	private ITrackRecordingService	myTracksService;
	private static int	           TAKE_PICTURE	       = 1;
	Track	                       tr;
	private ServiceConnection	   serviceConnection	= new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service)
        {
            myTracksService = ITrackRecordingService.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName className)
        {
            myTracksService = null;
        }
    };
	
	@SuppressWarnings({ "unchecked", "unchecked" })
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_layout);
		androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
		myTracksProviderUtils = MyTracksProviderUtils.Factory.get(this);
		
    	//attributeList = (ArrayList<Attribute>) getIntent().getSerializableExtra("attributeList");
		TableLayout tl = (TableLayout) findViewById(R.id.activity_mainTableLayout);
		
		LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		  
		//Iterator it= hashmap.keySet().iterator();
		
		
		dbHelper= new DBHelper(this);
    	db=dbHelper.openDatabase();
		Cursor  table_name_cursor = db.rawQuery("select * from " + ("MASTER_").concat(Domain_Selection.getSelectedItem()),null);
		if (table_name_cursor.moveToFirst()) {

            while (table_name_cursor.isAfterLast() == false) {
            	
                String attrString = table_name_cursor.getString(table_name_cursor.getColumnIndex("TABLE_ATTRIBUTE_TYPE"));
                String attrArray[]=null;
                int size;
                int index=0;
                Attribute attr= new Attribute();
                String[] attrValues;
                if(attrString.contains(" ")){
                	attrArray=attrString.split(" ");
                	size=attrArray.length;
                
                	while(size!=0)
                	{
                	
                			attrValues=attrArray[index].split("_");
                			index++;
                			attr.setName(attrValues[0]);
                			attr.setType(attrValues[1]);
                			attributeList.add(attr);
                			size--;
                	}
                }
            	else
        		{
        			attrValues=attrString.split("_");
        			attr.setName(attrValues[0]);
        			attr.setType(attrValues[1]);
        			attributeList.add(attr);
        		}
                //Cursor  cursor = db.rawQuery("select * from " + name ,null);
                //if (cursor.moveToFirst()) {
                	//while (cursor.isAfterLast() == false) {
                	/*	String att_name = table_name_cursor.getString(table_name_cursor.getColumnIndex("TABLE_NAME"));
                		String att_type = table_name_cursor.getString(table_name_cursor.getColumnIndex("TABLE_TYPE"));
                ;
                		cursor.moveToNext();*/
                		
                	//}
                //}
                	table_name_cursor.moveToNext();
                }
               // layerNames.add(name);
                
            
        }
		
		
		Iterator<Attribute> it=attributeList.iterator();
		while(it.hasNext()){
			TextView textview =new TextView(this); 
			textview.setText(it.next().getName().toString());
			EditText editText =new EditText(this);
			TableRow tr = new TableRow(this);
			tr.setLayoutParams(lp);
			tr.addView(textview);
			tr.addView(editText);
			tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
		
		Button back = (Button)findViewById(R.id.Bake_to_Login);
		back.setOnClickListener(new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
        		addRowToTable();
             	Intent mainIntent = new Intent(Main_Activity.this, LoginActivity.class);
				startActivity(mainIntent);
				Main_Activity.this.finish();

            } // end onClick
        });

		Button tap = (Button) findViewById(R.id.Take_Picture);
		tap.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{

				intent_cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			
				tr = myTracksProviderUtils.getLastTrack();
				String str=null;
				if (tr == null)
				{
					tr = new Track();
					tr.setId(1);
				}
			//	if (et_tno.getText().toString().length() > 0 && tree_name != null)
			//	{
					Toast.makeText(getApplicationContext(), "press only save button when you reached near to tree", Toast.LENGTH_LONG).show();
					Waypoint waypoint = new Waypoint();
					waypoint.setTrackId(tr.getId());
//					waypoint.setName(fno + "_" + et_tno.getText().toString());// .toLocaleString());
					waypoint.setName("pic1");// .toLocaleString());
//					waypoint.setDescription(tree_name);// .toLocaleString());
					waypoint.setDescription("tree_name");// .toLocaleString());
					waypoint.setCategory("Tree");
					waypoint.setLocation(myTracksProviderUtils.getLastValidTrackPoint());
					str = (System.currentTimeMillis() + "");
					str = str.substring(str.length() - 4, str.length());
//					File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + androidId + "/EMAGPS/", fno + "_" + et_tno.getText().toString() + "_" + str + ".jpg");
					File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + androidId + "/EMAGPS/", "pic1" + "_" + str + ".jpg");
					// Toast.makeText(getApplicationContext(),imagename+"1",
					// Toast.LENGTH_SHORT).show();
					outputFileUri = Uri.fromFile(file);
					intent_cam.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
					startActivityForResult(intent_cam, TAKE_PICTURE);
					// Toast.makeText(getApplicationContext(), ""+tr.getId(),
					// Toast.LENGTH_SHORT).show();

					(myTracksProviderUtils).insertWaypoint(waypoint);
			//	}
			//	else
			//	{
		//			Toast.makeText(getApplicationContext(), "Please Enter tree No. Or tree name", Toast.LENGTH_LONG).show();
			//	}
			}
		});
		
		
		/*Button add_table = (Button)findViewById(R.id.add_table);
		add_table.setOnClickListener(new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
        		addRowToTable();
             	Intent mainIntent = new Intent(Main_Activity.this, Attribute_Selection.class);
				startActivity(mainIntent);
				Main_Activity.this.finish();

            }

		// end onClick
        });
*/		
		
	}
	public void addRowToTable() {
		// TODO Auto-generated method stub
		Iterator<Attribute> it = attributeList.iterator();
		Attribute tempattr = new Attribute();
		TableLayout final_tl = (TableLayout) findViewById(R.id.activity_mainTableLayout);
		int rowPosition=1;
		TableRow row;
		int colPosition=1;
		EditText et;
		String text;
		while(it.hasNext())
		{
			row= (TableRow) final_tl.getChildAt(rowPosition);
			et=(EditText ) row.getChildAt(colPosition);
			tempattr =it.next();
			tempattr.setValue(et.getText().toString());
			rowPosition++;
		}
		dbHelper=new DBHelper(this);
		dbHelper.addRowToTable(attributeList);
	} 
}
